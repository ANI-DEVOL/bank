// pdf.service.js

const pdfMake = require('pdfmake/build/pdfmake');
const vfsFonts = require('pdfmake/build/vfs_fonts');

pdfMake.vfs = vfsFonts.pdfMake.vfs;

async function generatePDF(transactions, email, startDate, endDate) {
  const documentDefinition = {
    content: [
      { text: `Transaction Report for ${email}`, style: 'header' },
      { text: `Period: ${startDate.toDateString()} to ${endDate.toDateString()}`, style: 'subheader' },
      {
        table: {
          headers: ['Date', 'Amount'],
          body: transactions.map(transaction => [transaction.transactionDate.toDateString(), `$${transaction.amount}`]),
        },
      },
    ],
    styles: {
      header: {
        fontSize: 18,
        bold: true,
        margin: [0, 0, 0, 10],
      },
      subheader: {
        fontSize: 14,
        margin: [0, 0, 0, 10],
      },
    },
  };

  const pdf = pdfMake.createPdf(documentDefinition);
  return pdf;
}

module.exports = {
  generatePDF,
};
