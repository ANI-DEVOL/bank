// mongo.service.js

const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/bankingApp', { useNewUrlParser: true, useUnifiedTopology: true });

const transactionSchema = new mongoose.Schema({
  email: String,
  transactionDate: Date,
  amount: Number,
});

const Transaction = mongoose.model('Transaction', transactionSchema);

async function insertTransaction(email, transactionDate, amount) {
  const transaction = new Transaction({
    email,
    transactionDate,
    amount,
  });

  try {
    await transaction.save();
    console.log('Transaction inserted successfully.');
  } catch (error) {
    console.error('Error inserting transaction:', error.message);
    throw error;
  }
}

async function getTransactionsByEmailAndPeriod(email, startDate, endDate) {
  try {
    const transactions = await Transaction.find({
      email,
      transactionDate: { $gte: startDate, $lte: endDate },
    });

    return transactions;
  } catch (error) {
    console.error('Error retrieving transactions:', error.message);
    throw error;
  }
}

module.exports = {
  insertTransaction,
  getTransactionsByEmailAndPeriod,
};
