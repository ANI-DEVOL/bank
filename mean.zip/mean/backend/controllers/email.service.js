// email.service.js

const nodemailer = require('nodemailer');

async function sendEmail(to, subject, text, attachments) {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'xyz@gmail.com',
      pass: 'xyz@12345',
    },
  });

  const mailOptions = {
    from: 'xyz@gmail.com',
    to,
    subject,
    text,
    attachments,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Email sent successfully.');
  } catch (error) {
    console.error('Error sending email:', error.message);
    throw error;
  }
}

module.exports = {
  sendEmail,
};
