// app.js

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

// Import your services
const mongoService = require('./controllers/mongo.service');
const pdfService = require('./controllers/pdf.service');
const emailService = require('./controllers/email.service');
const cors=require('cors')
const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors())
// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/bankingApp', { useNewUrlParser: true});

// Define routes
app.post('/insert-transaction', async (req, res) => {
  const { email, transactionDate, amount } = req.body;

  try {
    // Insert the transaction into the database
    await mongoService.insertTransaction(email, new Date(transactionDate), amount);
    res.status(201).json({ message: 'Transaction inserted successfully' });
  } catch (error) {
    console.error('Error inserting transaction:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/generate-pdf-and-email', async (req, res) => {
  const { email, startDate, endDate } = req.body;
  const transactions = await mongoService.getTransactionsByEmailAndPeriod(email, new Date(startDate), new Date(endDate));
  const pdf = await pdfService.generatePDF(transactions, email, new Date(startDate), new Date(endDate));

  const emailSubject = 'Transaction Report';
  const emailText = 'Please find your transaction report attached.';

  await emailService.sendEmail(email, emailSubject, emailText, [{ filename: 'TransactionReport.pdf', content: pdf }]);
  res.send('PDF generated and emailed successfully.');
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
