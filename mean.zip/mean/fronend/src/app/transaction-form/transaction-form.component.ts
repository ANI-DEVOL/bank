

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-transaction-form',
  templateUrl: './transaction-form.component.html',
  styleUrls: ['./transaction-form.component.css']
})
export class TransactionFormComponent implements OnInit {
  transactionForm:any= FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {}
  ngOnInit(): void {
    this.initForm();
  }


  private initForm(): void {
    this.transactionForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      transactionDate: [null, Validators.required],
      amount: [null, [Validators.required, Validators.min(0)]],
    });
  }

  onSubmit(): void {
    if (this.transactionForm.valid) {
      const formData = this.transactionForm.value;
      
      // Make an HTTP POST request to your backend API
      this.http.post('http://localhost:3000/insert-transaction', formData)
        .subscribe(
          (response:any) => {
            console.log('Transaction inserted successfully:', response);
            // Optionally, you can reset the form after successful submission
            this.transactionForm.reset();
          },
          (error:any) => {
            console.error('Error inserting transaction:', error);
          }
        );
    }
  }
}
